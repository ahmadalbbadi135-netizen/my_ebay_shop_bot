"""
قاعدة بيانات SQLite بسيطة لتخزين الطلبات.
كل طلب فيه: الزبون، المنتج، السعر، العنوان، الحالة، رقم التتبع.
"""

import sqlite3
from contextlib import contextmanager

DB_PATH = "orders.db"


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_user_id INTEGER NOT NULL,
                telegram_username TEXT,
                item_id TEXT,
                item_title TEXT,
                item_url TEXT,
                sale_price REAL,
                currency TEXT,
                customer_name TEXT,
                shipping_address TEXT,
                phone_number TEXT,
                status TEXT DEFAULT 'قيد المراجعة',
                tracking_number TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)


def create_order(telegram_user_id, telegram_username, item) -> int:
    with get_conn() as conn:
        cursor = conn.execute(
            """INSERT INTO orders
               (telegram_user_id, telegram_username, item_id, item_title,
                item_url, sale_price, currency)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (telegram_user_id, telegram_username, item["item_id"],
             item["title"], item["item_url"], item["sale_price"], item["currency"]),
        )
        return cursor.lastrowid


def update_shipping_info(order_id: int, name: str, address: str, phone: str):
    with get_conn() as conn:
        conn.execute(
            """UPDATE orders SET customer_name=?, shipping_address=?,
               phone_number=?, status='بانتظار الشراء' WHERE id=?""",
            (name, address, phone, order_id),
        )


def set_tracking_number(order_id: int, tracking_number: str):
    with get_conn() as conn:
        conn.execute(
            "UPDATE orders SET tracking_number=?, status='تم الشحن' WHERE id=?",
            (tracking_number, order_id),
        )


def get_order(order_id: int):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
        return dict(row) if row else None


def get_orders_by_user(telegram_user_id: int):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM orders WHERE telegram_user_id=? ORDER BY id DESC",
            (telegram_user_id,),
        ).fetchall()
        return [dict(r) for r in rows]
