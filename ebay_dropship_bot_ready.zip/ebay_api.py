"""
وحدة التعامل مع eBay Browse API
- تجيب توكن OAuth (Application token) صالح للبحث عن المنتجات
- بتبحث عن منتجات بكلمة مفتاحية
- بترجع النتائج مع السعر بعد إضافة هامش الربح

ملاحظة مهمة: هاد الـ API بيسمح بالبحث والعرض فقط، مش الشراء الآلي.
الشراء لازم يصير يدوياً من قبل الأدمن (زي ما اتفقنا).
"""

import os
import time
import base64
import requests
from dotenv import load_dotenv

load_dotenv()

EBAY_CLIENT_ID = os.getenv("EBAY_CLIENT_ID")
EBAY_CLIENT_SECRET = os.getenv("EBAY_CLIENT_SECRET")
EBAY_MARKETPLACE_ID = os.getenv("EBAY_MARKETPLACE_ID", "EBAY_US")
PROFIT_MARGIN = float(os.getenv("PROFIT_MARGIN", "0.30"))

_token_cache = {"token": None, "expires_at": 0}


def get_app_token() -> str:
    """يجيب أو يجدد توكن OAuth الخاص بالتطبيق (client credentials flow)."""
    if _token_cache["token"] and time.time() < _token_cache["expires_at"] - 60:
        return _token_cache["token"]

    credentials = f"{EBAY_CLIENT_ID}:{EBAY_CLIENT_SECRET}"
    b64_creds = base64.b64encode(credentials.encode()).decode()

    resp = requests.post(
        "https://api.ebay.com/identity/v1/oauth2/token",
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": f"Basic {b64_creds}",
        },
        data={
            "grant_type": "client_credentials",
            "scope": "https://api.ebay.com/oauth/api_scope",
        },
        timeout=15,
    )
    resp.raise_for_status()
    data = resp.json()
    _token_cache["token"] = data["access_token"]
    _token_cache["expires_at"] = time.time() + data["expires_in"]
    return _token_cache["token"]


def search_items(keyword: str, limit: int = 8) -> list[dict]:
    """
    بتبحث بـ eBay عن منتجات مطابقة للكلمة المفتاحية.
    بترجع لستة فيها: العنوان، السعر الأصلي، السعر بعد الهامش، الصورة، الرابط.
    """
    token = get_app_token()
    resp = requests.get(
        "https://api.ebay.com/buy/browse/v1/item_summary/search",
        headers={
            "Authorization": f"Bearer {token}",
            "X-EBAY-C-MARKETPLACE-ID": EBAY_MARKETPLACE_ID,
        },
        params={"q": keyword, "limit": limit},
        timeout=15,
    )
    resp.raise_for_status()
    items = resp.json().get("itemSummaries", [])

    results = []
    for item in items:
        try:
            original_price = float(item["price"]["value"])
            currency = item["price"]["currency"]
        except (KeyError, TypeError):
            continue

        sale_price = round(original_price * (1 + PROFIT_MARGIN), 2)

        results.append({
            "item_id": item.get("itemId"),
            "title": item.get("title"),
            "image_url": item.get("image", {}).get("imageUrl"),
            "item_url": item.get("itemWebUrl"),
            "original_price": original_price,
            "sale_price": sale_price,
            "currency": currency,
        })

    return results
