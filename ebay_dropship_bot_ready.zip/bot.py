"""
بوت تيليجرام لدروب شوبينج من eBay - النسخة الأساسية

سير العمل:
1. الزبون يكتب /search + كلمة مفتاحية → البوت يعرض منتجات من eBay بسعر فيه هامش ربح
2. الزبون يضغط "اطلب" على منتج → البوت يسأله عن الاسم/العنوان/رقم الهاتف
3. بعد ما يكمل بياناته → إشعار فوري للأدمن بكل التفاصيل
4. الأدمن يشتري يدوياً من eBay ويشحن لعنوان الزبون
5. الأدمن يستخدم /track <رقم الطلب> <رقم التتبع> → البوت يرسل رقم التتبع للزبون تلقائياً

شغل البوت: python bot.py
"""

import os
import logging
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, ConversationHandler, ContextTypes, filters
)

import ebay_api
import database

load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
ADMIN_CHAT_ID = os.getenv("ADMIN_CHAT_ID")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# حالات محادثة إدخال بيانات الشحن
ASK_NAME, ASK_ADDRESS, ASK_PHONE = range(3)

# تخزين مؤقت لنتائج البحث الأخيرة لكل مستخدم (بالذاكرة، بسيط بالبداية)
user_search_cache: dict[int, list] = {}


# ---------- أوامر عامة ----------

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "أهلاً فيك! 👋\n\n"
        "اكتب /search متبوعة بالمنتج يلي بدك ياه، مثال:\n"
        "/search wireless headphones\n\n"
        "لعرض طلباتك السابقة اكتب /myorders"
    )


async def search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("اكتب كلمة البحث بعد الأمر، مثال:\n/search laptop stand")
        return

    keyword = " ".join(context.args)
    await update.message.reply_text(f"🔍 عم بدور على: {keyword} ...")

    try:
        results = ebay_api.search_items(keyword)
    except Exception as e:
        logger.error(f"eBay search error: {e}")
        await update.message.reply_text("صار خطأ بالبحث، جرب كمان مرة بعد شوي.")
        return

    if not results:
        await update.message.reply_text("ما لقيت نتائج، جرب كلمة تانية.")
        return

    user_search_cache[update.effective_user.id] = results

    for idx, item in enumerate(results):
        caption = (
            f"🛍 {item['title']}\n"
            f"💰 السعر: {item['sale_price']} {item['currency']}"
        )
        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton("اطلب هالمنتج ✅", callback_data=f"order_{idx}")
        ]])
        if item["image_url"]:
            await update.message.reply_photo(
                photo=item["image_url"], caption=caption, reply_markup=keyboard
            )
        else:
            await update.message.reply_text(caption, reply_markup=keyboard)


async def myorders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    orders = database.get_orders_by_user(update.effective_user.id)
    if not orders:
        await update.message.reply_text("ما عندك طلبات لسا.")
        return

    lines = []
    for o in orders:
        line = f"#{o['id']} - {o['item_title'][:40]} - {o['status']}"
        if o["tracking_number"]:
            line += f"\n📦 رقم التتبع: {o['tracking_number']}"
        lines.append(line)

    await update.message.reply_text("\n\n".join(lines))


# ---------- محادثة الطلب (بعد الضغط على زر "اطلب") ----------

async def order_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    idx = int(query.data.split("_")[1])
    user_id = update.effective_user.id
    results = user_search_cache.get(user_id, [])

    if idx >= len(results):
        await query.message.reply_text("المنتج مش متوفر، جرب تبحث كمان مرة.")
        return ConversationHandler.END

    item = results[idx]
    order_id = database.create_order(
        user_id, update.effective_user.username, item
    )
    context.user_data["current_order_id"] = order_id

    await query.message.reply_text(
        "تمام، بس بدنا بيانات الشحن منك:\n\nشو اسمك الكامل؟"
    )
    return ASK_NAME


async def ask_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["name"] = update.message.text
    await update.message.reply_text("تمام، هلأ ابعتلي عنوانك الكامل (مدينة، حي، شارع، أقرب معلم):")
    return ASK_ADDRESS


async def ask_address(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["address"] = update.message.text
    await update.message.reply_text("وأخيراً، رقم هاتفك للتواصل عند التوصيل:")
    return ASK_PHONE


async def ask_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    phone = update.message.text
    order_id = context.user_data["current_order_id"]
    name = context.user_data["name"]
    address = context.user_data["address"]

    database.update_shipping_info(order_id, name, address, phone)
    order = database.get_order(order_id)

    await update.message.reply_text(
        f"تم استلام طلبك ✅ (رقم الطلب #{order_id})\n"
        "رح نتواصل معك لتأكيد الدفع، وبعدها نجهز طلبك."
    )

    # إشعار الأدمن بكل تفاصيل الطلب
    if ADMIN_CHAT_ID:
        admin_msg = (
            f"🆕 طلب جديد #{order_id}\n\n"
            f"المنتج: {order['item_title']}\n"
            f"الرابط: {order['item_url']}\n"
            f"السعر: {order['sale_price']} {order['currency']}\n\n"
            f"الزبون: {name}\n"
            f"العنوان: {address}\n"
            f"الهاتف: {phone}\n"
            f"يوزر تيليجرام: @{update.effective_user.username}\n\n"
            f"لما تشحن الطلب استخدم:\n/track {order_id} <رقم_التتبع>"
        )
        await context.bot.send_message(chat_id=ADMIN_CHAT_ID, text=admin_msg)

    return ConversationHandler.END


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("تم إلغاء العملية.")
    return ConversationHandler.END


# ---------- أوامر الأدمن ----------

async def track(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if str(update.effective_chat.id) != str(ADMIN_CHAT_ID):
        await update.message.reply_text("هاد الأمر للأدمن فقط.")
        return

    if len(context.args) < 2:
        await update.message.reply_text("الصيغة: /track <رقم_الطلب> <رقم_التتبع>")
        return

    order_id = int(context.args[0])
    tracking_number = " ".join(context.args[1:])

    order = database.get_order(order_id)
    if not order:
        await update.message.reply_text("ما لقيت هيك طلب.")
        return

    database.set_tracking_number(order_id, tracking_number)

    await context.bot.send_message(
        chat_id=order["telegram_user_id"],
        text=(
            f"📦 طلبك #{order_id} تم شحنه!\n"
            f"رقم التتبع: {tracking_number}"
        ),
    )
    await update.message.reply_text(f"تم تحديث الطلب #{order_id} وإشعار الزبون.")


def main():
    database.init_db()
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    order_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(order_callback, pattern=r"^order_\d+$")],
        states={
            ASK_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_name)],
            ASK_ADDRESS: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_address)],
            ASK_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_phone)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("search", search))
    app.add_handler(CommandHandler("myorders", myorders))
    app.add_handler(CommandHandler("track", track))
    app.add_handler(order_conv)

    logger.info("البوت شغال...")
    app.run_polling()


if __name__ == "__main__":
    main()
